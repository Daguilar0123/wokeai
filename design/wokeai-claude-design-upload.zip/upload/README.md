# wokeai

One lowercase word. Pronounced *wohk/ē/eye*.

Brand: **wokeai**. Website: **wokeainow.com** (Danny's choice, October 18, 2026; $45.99 for three years at GoDaddy, then $22.99/yr; not yet purchased as of this commit).

An aspirational brand and community: a website and social profiles gathering people around grassroots resistance to systemic oppression, from students and independent researchers using their own AI to tools built and shared in the open. Pillars: open source, liberation, community. It answers Executive Order 14319, "Preventing Woke AI in the Federal Government" (July 23, 2025), and is informed by the Black liberation struggle in America.

Not an AI product yet. As of October 2026 there is no budget, so this starts as a site that spreads awareness, shares existing tools, and gathers people who want to build.

## What is here

- `marks/a-roots.svg` — **the wokeai mark.** Grass above a ground line; below it the roots are drawn as a git graph: a main branch, one branch merged back (the lane on the left), two open branches. One color (`currentColor`), safe inside a circle crop, built to sit beside the lowercase wordmark.
- `marks/b-heard.svg` — **reserved for the podcast, working name *wahkeeye*.** Three arcs of sound arriving at a listening point. Deliberately not the Wi‑Fi construction: nothing is emitted, something is heard.
- `preview.html` — both marks at 512 / 64 / 32 / 16 px, light and dark, in the circle crop, beside the wordmark, with lookalike glyphs (a plain git graph, the Wi‑Fi glyph) for the risk check. Open it in a browser.

## Decisions, dated

Danny decided (October 18, 2026):

- **Mark A is the symbol.** Chosen on sight from the first preview, with one tweak: the roots must read as a git graph with a main branch, two open branches, and one merged branch. Three revisions followed to stop the merge bulge and a lower branch from forming a letter R.
- **Mark B is not scrapped.** It is held for the podcast.
- **Theology stays implicit** in the public brand. The images carry it; the site speaks in liberation and open-source language and is interfaith by default. Sources get named on Tattered Rose, not here.
- **The old placeholder (an open eye with rays) is replaced.** It read as the watcher, and the whole point is the watched being heard.
- **The spoken form is *wohk/ē/eye*.** An earlier "whoa-keyah" came from misreading *wokeai* as *wokeia*; Danny caught it the same day. The pronunciation line sits under the wordmark on purpose: the spelling says one thing to a glance, and the brand tells you how it is actually said.
- **Domain: wokeainow.com.** The exact-name .com is a $3,762 premium and woke.ai is taken; wokeainow.com keeps the brand spelled exactly and costs $22.99/yr. The brand stays "wokeai," never "wokeainow."
- **The podcast is *wahkeeye*, tagline "pronounced wōke•ĀĪ."** Danny proposed flipping the whole brand to this spelling (October 18, 2026) and decided against it the same day: the main brand stays one legible lowercase word, and the spelled-from-sound name goes to the one medium that is heard rather than seen. The letters are Google's respelling of *wok·e·ai* (wok as in the pan: *wäk*); the "woke" lives in the tagline, which is the joke. Mark B is its mark. Domain `wahkeeye.com` was $45.99 for three years at GoDaddy when checked; not purchased, and not needed until the show exists. Known risks, recorded so they get tested before launch: the word reads like a Pacific Northwest Indigenous place name (cf. Wahkiakum, Wahkon); it is hard to spell from hearing; it puts "eye" back in a name.

## Where the ideas come from

- *Grass roots*: Malcolm X, "Message to the Grass Roots," King Solomon Baptist Church, Detroit, November 10, 1963, is the one speech whose transcript excerpt was verified during research. The brand borrows the idea of the field, not any quotation, likeness, or signature.
- *Roots as a commons*: open-source forking, and the symbiosis image in Danny's own writing (2014, 2025): what sustains a thing is the network underneath it, shared.
- *The heard cry*: the inversion of the surveillance eye. Being awake, in the liberation tradition, is hearing the cry, not watching from above.

## Not done yet

- No trademark or availability search has been run on "wokeai" or on either mark.
- The 16 px favicon needs its own simplified cut of mark A.
- No site shell, no license file, no public repo. Open source is a pillar, so the license choice comes before anything is published.
